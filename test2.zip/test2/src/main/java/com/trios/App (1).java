
package com.trios;

import jakarta.persistence.*;


import java.util.*;


public class App
{
    private static EntityManagerFactory emf=
            Persistence.createEntityManagerFactory("DBApp2");
    public static void main( String[] args )
    {
        Scanner scanner = new Scanner(System.in);
    }
    public static void createCustomer(String name,int albumId,int mediaTypeId,int genreId,String composer,int milliseconds,int bytes,float unitPrice){
        EntityManager em= emf.createEntityManager();
        EntityTransaction et = null;
        try{
            et=em.getTransaction();
            et.begin();
            Track t = new Track();
            t.setUnitPrice(unitPrice);
            t.setName(name);
            t.setAlbumId(albumId);
            t.setBytes(bytes);
            t.setComposer(composer);
            t.setGenreId(genreId);
            t.setMediaTypeId(mediaTypeId);
            t.setMilliseconds(milliseconds);

            em.persist(t);
            et.commit();
        }catch(Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }
    public static void PriceUpdate(int Id,float price){
        EntityManager em= emf.createEntityManager();
        String query_string;
        EntityTransaction et = null;
        try{
            TypedQuery<Track> q =em.createQuery("Update Track SET UnitPrice=:price where TrackId=:id;",Track.class);
            q.setParameter("price",price);
            q.setParameter("id",Id);
            q.executeUpdate();
        }catch(Exception ex){
            if(et!=null){
                et.rollback();
            }
        }finally {
            em.close();
        }
    }
    public static void getPrice(String name){
        EntityManager em= emf.createEntityManager();
        String query_string;
        try{
            TypedQuery<Track> q =em.createQuery("select t from Track where t.Name=:n;",Track.class);
            q.setParameter(name,"n");
            Track T =q.getSingleResult();
            System.out.println(T.getUnitPrice());


        }catch(Exception ex){
            ex.printStackTrace();
        }finally {
            em.close();
        }

    }
}
